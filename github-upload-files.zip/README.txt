HAYWIZZ KITCHEN – Android app (APK) source
===========================================
What it does
 - Opens your kitchen page (https://haywizzmenu.netlify.app/kitchen.html) as a real app.
 - A foreground service keeps checking for NEW orders even with the screen off / app closed:
   speaks "Room order. Room 101. 1 Chicken Briyani." or "Online delivery order from <name>. ..." (repeats every 25 s until accepted)
   and shows a notification with vibration. Restarts after the phone reboots.
 - Prints KOT through Android's print system.

Build the APK online (free, no software to install)
 1. Create a free account at github.com  ->  New repository  -> name: haywizz-kitchen-app  (Private is fine).
 2. Upload ALL files of this folder to the repository (on a computer: drag the folder contents onto the repo page).
    Make sure the hidden folder  .github/workflows/build.yml  is included.
 3. Open the repository -> Actions tab -> "Build Android APK" -> wait ~4 minutes until it shows a green tick.
 4. Click the finished run -> Artifacts -> "Haywizz-Kitchen-APK" -> download, unzip -> app-debug.apk
 5. Send the APK to the kitchen phone/tablet, tap it, allow "Install unknown apps".
 6. Open Haywizz Kitchen -> allow Notifications -> allow "Unrestricted battery" -> sign in -> Start.

If your website address changes, edit URL at the top of app/src/main/java/com/haywizz/kitchen/MainActivity.java.
