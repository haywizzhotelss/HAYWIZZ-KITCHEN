package com.haywizz.kitchen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

/**
 * Foreground service: checks the database every few seconds for NEW orders, speaks each one aloud
 * (table / room / online customer name + dishes) and shows a notification. Works with the screen off.
 */
public class OrderService extends Service implements TextToSpeech.OnInitListener {

    static volatile boolean running = false;

    private static final String CH_SVC = "hz_service";
    private static final String CH_ORD = "hz_orders";
    private static final int SVC_ID = 1;
    private static final long POLL_MS = 4000;
    private static final long REPEAT_MS = 20000;

    private SharedPreferences sp;
    private PowerManager.WakeLock wl;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean stop = false;
    private Thread loop;
    private NotificationManager nm;

    private String token = null;
    private long tokenExp = 0;
    private String lastStatus = "";
    private final Set<String> announced = new HashSet<>();
    private long lastRound = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("hz", MODE_PRIVATE);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationChannel svc = new NotificationChannel(CH_SVC, "Kitchen running", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(svc);
        NotificationChannel ord = new NotificationChannel(CH_ORD, "New orders", NotificationManager.IMPORTANCE_HIGH);
        ord.setSound(null, null);                       // no beep – the voice announces the order
        ord.enableVibration(true);
        ord.setVibrationPattern(new long[]{0, 400, 150, 400, 150, 800});
        nm.createNotificationChannel(ord);

        tts = new TextToSpeech(this, this);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "haywizz:orders");
        wl.setReferenceCounted(false);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(new Locale("en", "IN"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.ENGLISH);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
        tts.setSpeechRate(0.95f);
        ttsReady = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if ("STOP".equals(action)) {
            sp.edit().putBoolean("enabled", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = serviceNotification(lastStatus.isEmpty() ? "Starting…" : lastStatus);
        if (Build.VERSION.SDK_INT >= 34) startForeground(SVC_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(SVC_ID, n);
        running = true;
        if (!wl.isHeld()) wl.acquire();

        if ("SAY".equals(action) && intent.getStringExtra("text") != null) speak(intent.getStringExtra("text"));
        if ("RELOGIN".equals(action)) { token = null; tokenExp = 0; }

        if (loop == null || !loop.isAlive()) {
            stop = false;
            loop = new Thread(this::runLoop, "hz-poll");
            loop.start();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        stop = true;
        running = false;
        if (loop != null) loop.interrupt();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }

    /* ---------------- polling ---------------- */

    private void runLoop() {
        while (!stop) {
            try {
                poll();
            } catch (InterruptedException ie) {
                break;
            } catch (Exception e) {
                setStatus("No internet – retrying");
            }
            try { Thread.sleep(POLL_MS); } catch (InterruptedException e) { break; }
        }
    }

    private void poll() throws Exception {
        String url = sp.getString("url", "");
        String key = sp.getString("key", "");
        if (url.isEmpty() || key.isEmpty()) { setStatus("Open the app and sign in"); return; }
        if (token == null || System.currentTimeMillis() > tokenExp) login(url, key);
        if (token == null) return;

        String q = url + "/rest/v1/orders?select=id,order_no,source,order_type,location_label,location_kind,table_no,customer_name,items"
                + "&status=eq.new&order=created_at.asc&limit=50";
        String[] res = http("GET", q, key, token, null);
        if ("401".equals(res[0]) || "403".equals(res[0])) { token = null; return; }
        if (!res[0].startsWith("2")) { setStatus("Server error " + res[0] + " – retrying"); return; }

        JSONArray arr = new JSONArray(res[1]);          // oldest first from the server
        boolean voice = sp.getBoolean("voice", true);
        long now = System.currentTimeMillis();
        Set<String> current = new HashSet<>();
        boolean anyNew = false;

        // brand-new orders: notify + speak, newest first
        for (int i = arr.length() - 1; i >= 0; i--) {
            JSONObject o = arr.getJSONObject(i);
            String id = o.getString("id");
            current.add(id);
            if (!announced.contains(id)) {
                notifyOrder(o);
                if (voice) speak(announceText(o));
                announced.add(id);
                anyNew = true;
            }
        }
        if (anyNew) lastRound = now;

        // every few seconds repeat the voice for EVERY order still waiting (newest first) until it is accepted
        if (voice && !anyNew && arr.length() > 0 && now - lastRound > REPEAT_MS && !(ttsReady && tts.isSpeaking())) {
            for (int i = arr.length() - 1; i >= 0; i--) speak(announceText(arr.getJSONObject(i)));
            lastRound = now;
        }

        // orders that are no longer "new" (accepted / cancelled): clear their notification
        Iterator<String> it = announced.iterator();
        while (it.hasNext()) {
            String id = it.next();
            if (!current.contains(id)) { nm.cancel(id.hashCode()); it.remove(); }
        }
        setStatus(arr.length() == 0 ? "Listening for new orders" : arr.length() + " new order(s) waiting");
    }

    private void login(String url, String key) throws Exception {
        String email = sp.getString("email", ""), pass = sp.getString("pass", "");
        if (email.isEmpty() || pass.isEmpty()) { setStatus("Open the app and sign in"); return; }
        JSONObject body = new JSONObject().put("email", email).put("password", pass);
        String[] res = http("POST", url + "/auth/v1/token?grant_type=password", key, null, body.toString());
        if (!res[0].startsWith("2")) {
            token = null;
            setStatus("Login failed – open the app and sign in again");
            return;
        }
        JSONObject j = new JSONObject(res[1]);
        token = j.getString("access_token");
        long exp = j.optLong("expires_in", 3600);
        tokenExp = System.currentTimeMillis() + Math.max(60, exp - 120) * 1000L;
    }

    /** returns {statusCode, body} */
    private String[] http(String method, String urlStr, String key, String bearer, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new java.net.URL(urlStr).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("apikey", key);
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        c.setRequestProperty("Accept", "application/json");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes("UTF-8")); }
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
            is.close();
        }
        c.disconnect();
        return new String[]{String.valueOf(code), sb.toString()};
    }

    /* ---------------- voice + notifications ---------------- */

    private static String str(JSONObject o, String k) { return o.isNull(k) ? "" : o.optString(k, ""); }

    private static String say(String s) {
        return s.replace("&", " and ").replaceAll("[/()]", " ").replaceAll("\\s+", " ").trim();
    }

    private String locLabel(JSONObject o) {
        String l = str(o, "location_label");
        if (!l.isEmpty()) return l;
        String t = str(o, "table_no");
        return t.isEmpty() ? "Table" : "Table " + t;
    }

    private String announceText(JSONObject o) {
        StringBuilder items = new StringBuilder();
        JSONArray arr = o.optJSONArray("items");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject it = arr.optJSONObject(i);
                if (it == null) continue;
                String name = str(it, "n"), label = str(it, "l");
                if (items.length() > 0) items.append(", ");
                items.append(it.optInt("q", 1)).append(' ').append(say(name + (label.isEmpty() ? "" : " " + label)));
            }
        }
        String head;
        if ("table".equals(str(o, "source"))) {
            head = ("room".equals(str(o, "location_kind")) ? "Room order. " : "Table order. ") + say(locLabel(o)) + ".";
        } else {
            String name = str(o, "customer_name");
            head = ("delivery".equals(str(o, "order_type")) ? "Online delivery order" : "Online take away order")
                    + (name.isEmpty() ? "" : " from " + say(name)) + ".";
        }
        return head + " " + items + ".";
    }

    private void speak(String text) {
        if (!ttsReady || text == null) return;
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "hz" + System.nanoTime());
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void notifyOrder(JSONObject o) {
        try {
            boolean table = "table".equals(str(o, "source"));
            String no = str(o, "order_no");
            String name = str(o, "customer_name");
            String title = table ? "🔔 " + locLabel(o) + " – new order #" + no
                    : "🛵 Online order #" + no + (name.isEmpty() ? "" : " – " + name);
            StringBuilder body = new StringBuilder();
            JSONArray arr = o.optJSONArray("items");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                JSONObject it = arr.optJSONObject(i);
                if (it == null) continue;
                if (body.length() > 0) body.append(", ");
                String l = str(it, "l");
                body.append(it.optInt("q", 1)).append("× ").append(str(it, "n")).append(l.isEmpty() ? "" : " (" + l + ")");
            }
            Notification n = new Notification.Builder(this, CH_ORD)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(body.toString())
                    .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                    .setContentIntent(openApp())
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setOnlyAlertOnce(false)
                    .setAutoCancel(false)
                    .build();
            nm.notify(o.getString("id").hashCode(), n);
        } catch (Exception e) { /* ignore */ }
    }

    private Notification serviceNotification(String text) {
        Intent stop = new Intent(this, OrderService.class).setAction("STOP");
        PendingIntent sp2 = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action act = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat), "Stop", sp2).build();
        return new Notification.Builder(this, CH_SVC)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Haywizz Kitchen")
                .setContentText(text)
                .setContentIntent(openApp())
                .setOngoing(true)
                .addAction(act)
                .build();
    }

    private void setStatus(String s) {
        if (s.equals(lastStatus)) return;
        lastStatus = s;
        nm.notify(SVC_ID, serviceNotification(s));
    }
}
