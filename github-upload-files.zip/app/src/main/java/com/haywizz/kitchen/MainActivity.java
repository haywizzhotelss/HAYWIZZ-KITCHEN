package com.haywizz.kitchen;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/** Haywizz Kitchen: shows the kitchen web app full screen. Background alerts are done by OrderService. */
public class MainActivity extends Activity {

    /** The kitchen page on your website. Change this if your website address changes. */
    static final String URL = "https://haywizzmenu.netlify.app/kitchen.html";

    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("hz", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.addJavascriptInterface(new Bridge(), "HaywizzNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String host = Uri.parse(URL).getHost();
                if (u.getHost() != null && u.getHost().equals(host)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { /* ignore */ }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    v.loadData("<html><body style='background:#121110;color:#f4efe6;font-family:sans-serif;text-align:center;padding-top:30%'>"
                            + "<h2>No internet</h2><p>Retrying…</p></body></html>", "text/html", "utf-8");
                    handler.postDelayed(() -> web.loadUrl(URL), 5000);
                }
            }
        });
        web.loadUrl(URL);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        // Ask once to be exempt from battery optimisation so Android doesn't stop the alerts.
        handler.postDelayed(this::askBatteryOnce, 4000);
    }

    private void askBatteryOnce() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!sp.getBoolean("asked_batt", false) && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                sp.edit().putBoolean("asked_batt", true).apply();
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            }
        } catch (Exception e) { /* ignore */ }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else moveTaskToBack(true);   // keep running in background
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    /** Functions the kitchen web page can call as window.HaywizzNative.* */
    class Bridge {
        @JavascriptInterface
        public boolean isNative() { return true; }

        @JavascriptInterface
        public String savedLogin() {
            try {
                JSONObject o = new JSONObject();
                o.put("email", sp.getString("email", ""));
                o.put("pass", sp.getString("pass", ""));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public boolean serviceRunning() { return OrderService.running; }

        @JavascriptInterface
        public void startService(String url, String key, String email, String pass, boolean voice) {
            sp.edit().putString("url", url).putString("key", key).putString("email", email)
                    .putString("pass", pass).putBoolean("voice", voice).putBoolean("enabled", true).apply();
            Intent i = new Intent(MainActivity.this, OrderService.class);
            if (OrderService.running) { i.setAction("RELOGIN"); }
            MainActivity.this.startForegroundService(i);
        }

        @JavascriptInterface
        public void stopService() {
            sp.edit().putBoolean("enabled", false).remove("pass").apply();
            MainActivity.this.stopService(new Intent(MainActivity.this, OrderService.class));
        }

        @JavascriptInterface
        public void setVoice(boolean on) {
            sp.edit().putBoolean("voice", on).apply();
            if (on && OrderService.running) {
                Intent i = new Intent(MainActivity.this, OrderService.class);
                i.setAction("SAY").putExtra("text", "Voice announcements on");
                MainActivity.this.startService(i);
            }
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("Haywizz KOT", web.createPrintDocumentAdapter("KOT"), new PrintAttributes.Builder().build());
            });
        }
    }
}
