package com.haywizz.kitchen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Restarts the order alerts after the phone / tablet reboots. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        SharedPreferences sp = ctx.getSharedPreferences("hz", Context.MODE_PRIVATE);
        if (sp.getBoolean("enabled", false) && !sp.getString("url", "").isEmpty()) {
            try { ctx.startForegroundService(new Intent(ctx, OrderService.class)); } catch (Exception e) { /* ignore */ }
        }
    }
}
